var Config=require('../Common/Config')
const MongoClient=require('mongodb').MongoClient

exports.DAL_AddNewLoggs=function(req,callback)
{
    MongoClient.connect(Config.mongodbUrl,{ useUnifiedTopology: true },function(err,client)
    {
        var db = client.db("Logger");
        var collection = db.collection("WApi_Log");
        
        collection.insertOne(req.body)
        .then(result => {
          callback({'SuccessCode':'1','Message':'Logs is added successfully'})
        })
        .catch(error => callback({'SuccessCode':'0','Message':'Logs is not added successfully'}));
    });
    
}

exports.DAL_GetLoggs=function(req,callback)
{
    MongoClient.connect(Config.mongodbUrl,{ useUnifiedTopology: true },function(err,client)
    {
        var db = client.db("Logger");
        var collection = db.collection("WApi_Log");
        
        var cursor = collection.find().toArray()
        .then(results => {
            callback({'SuccessCode':'1','Message':'Getting Logs is successfully','Results': results})           
        })
        .catch(error =>callback({'SuccessCode':'0','Message':'Error during getting logs'}))        
    });
}