var DAL=require("./DAL");

exports.BAL_AddNewLoggs=function(req,callback)
{
    DAL.DAL_AddNewLoggs(req,function(data,err)
    {
        callback(data);
    });    
}


exports.BAL_GetLoggs=function(req,callback)
{
    DAL.DAL_GetLoggs(req,function(data,err)
    {
        callback(data);

    });    
}