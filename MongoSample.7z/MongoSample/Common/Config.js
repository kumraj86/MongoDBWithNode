exports.WhilteListIpAddress=["127.0.0.1","10.75.19.87","10.16.240.6","::1","::ffff:192.168.29.191"]
exports.mongodbUrl="mongodb://localhost:27017/Logger";

