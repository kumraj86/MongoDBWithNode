const express=require("express");
const app=express();

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

// Set Content -type= application/json in postman
var BAL_Logger=require("./LoggerM/BAL");
app.post('/api/loggers/AddNewLoggs',function(req,res)
{    
    BAL_Logger.BAL_AddNewLoggs(req,function(data,err){
        res.send(data);    
    });
})

app.post('/api/loggers/GetLoggs',function(req,res)
{
    BAL_Logger.BAL_GetLoggs(req,function(data,err){
        res.send(data);    
    });
})

app.listen(5001, function (req, res) {
    console.log("Hello");
  });